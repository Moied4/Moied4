package webFaculty;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/webfaculty")
public class WebFacultyServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private List<Faculty> getCartoonTeachers() {
        List<Faculty> teachers = new ArrayList<>();

        teachers.add(new Faculty("Ms. Frizzle", "Science", "frizzle@magicbus.com"));
        teachers.add(new Faculty("Mr. Garrison", "Social Studies", "garrison@southpark.edu"));
        teachers.add(new Faculty("Edna Krabappel", "4th Grade", "krabappel@springfield.edu"));
        teachers.add(new Faculty("Mr. Ratburn", "3rd Grade", "ratburn@elwoodschool.edu"));
        teachers.add(new Faculty("Daria Morgendorffer", "Literature", "daria@lawndalehigh.edu"));

        return teachers;
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        List<Faculty> facultyList = getCartoonTeachers();

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>Cartoon Faculty</title></head><body>");
        out.println("<h2>Famous Cartoon Teachers</h2>");
        out.println("<table border='1' cellpadding='10'>");
        out.println("<tr><th>Name</th><th>Department</th><th>Email</th></tr>");

        for (Faculty f : facultyList) {
            out.println("<tr>");
            out.println("<td>" + f.getName() + "</td>");
            out.println("<td>" + f.getDepartment() + "</td>");
            out.println("<td>" + f.getEmail() + "</td>");
            out.println("</tr>");
        }

        out.println("</table>");
        out.println("</body></html>");
    }
}
