package webCourse;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/WebCourseServlet")
public class WebCourseServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Create array of Course objects
        Course[] courseRecords = new Course[7];

        // Initialize the array
        for (int i = 0; i < courseRecords.length; i++) {
            courseRecords[i] = new Course(); // default constructor
        }

        // Sample data
        String[] courseNos = { "IT101", "DB202", "WD203", "AI301", "ML302", "CS204", "NET205" };
        String[] courseNames = {
            "Fundamentals of IT",
            "Database Systems",
            "Web Development",
            "Artificial Intelligence",
            "Machine Learning",
            "Data Structures",
            "Computer Networks"
        };
        int[] maxEnrollments = { 35, 40, 25, 30, 20, 32, 28 };
        int credits = 4;

        for (int i = 0; i < courseRecords.length; i++) {
            courseRecords[i].setCourse_no(courseNos[i]);
            courseRecords[i].setCourse_name(courseNames[i]);
            courseRecords[i].setMax_enrl(maxEnrollments[i]);
            courseRecords[i].setCredits(credits);
        }

        // Output HTML
        out.println("<html><head><title>Courses</title></head><body>");
        out.println("<h1>Course List</h1>");
        out.println("<table border='1'>");
        out.println("<tr><th>Course No</th><th>Course Name</th><th>Max Enrl</th><th>Credits</th><th>Total Fees</th></tr>");

        for (Course c : courseRecords) {
            out.println("<tr>");
            out.println("<td>" + c.getCourse_no() + "</td>");
            out.println("<td>" + c.getCourse_name() + "</td>");
            out.println("<td>" + c.getMax_enrl() + "</td>");
            out.println("<td>" + c.getCredits() + "</td>");
            out.println("<td>$" + c.calculateTotalFees() + "</td>");
            out.println("</tr>");
        }

        out.println("</table></body></html>");
    }
}
