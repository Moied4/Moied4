package webBilling;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/WebBillingServlet")
public class WebBillingServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public WebBillingServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Set static tax values
        Billing.Fed_Tax = 0.075;
        Billing.Prv_Tax = 0.06;

        // Create Billing array
        Billing[] BillingRecords = new Billing[3];
        for (int i = 0; i < BillingRecords.length; i++) {
            BillingRecords[i] = new Billing();
        }

        // Set data for each Billing object
        BillingRecords[0].setClient_LName("Johnston");
        BillingRecords[0].setClient_FName("Jane");
        BillingRecords[0].setProduct_Name("Chair");
        BillingRecords[0].setPrd_Price(99.99);
        BillingRecords[0].setPrd_Qty(2);

        BillingRecords[1].setClient_LName("Fikhali");
        BillingRecords[1].setClient_FName("Samuel");
        BillingRecords[1].setProduct_Name("Table");
        BillingRecords[1].setPrd_Price(139.99);
        BillingRecords[1].setPrd_Qty(1);

        BillingRecords[2].setClient_LName("Samson");
        BillingRecords[2].setClient_FName("Amina");
        BillingRecords[2].setProduct_Name("KeyUSB");
        BillingRecords[2].setPrd_Price(14.99);
        BillingRecords[2].setPrd_Qty(2);

        // Generate HTML output
        out.println("<html><head><title>Billing Records</title></head><body>");
        out.println("<h2>Client Billing Table</h2>");
        out.println("<table border='1'>");
        out.println("<tr><th>Last Name</th><th>First Name</th><th>Product</th><th>Price</th><th>Qty</th><th>Total Billing</th></tr>");

        for (Billing b : BillingRecords) {
            out.println("<tr>");
            out.println("<td>" + b.getClient_LName() + "</td>");
            out.println("<td>" + b.getClient_FName() + "</td>");
            out.println("<td>" + b.getProduct_Name() + "</td>");
            out.println("<td>$" + b.getPrd_Price() + "</td>");
            out.println("<td>" + b.getPrd_Qty() + "</td>");
            out.printf("<td>$%.2f</td>%n", b.CalculateBilling());
            out.println("</tr>");
        }

        out.println("</table>");
        out.println("</body></html>");
        out.close();
    }
}
