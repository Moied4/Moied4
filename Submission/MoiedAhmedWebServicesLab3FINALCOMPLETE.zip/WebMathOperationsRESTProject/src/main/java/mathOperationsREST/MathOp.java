package mathOperationsREST;

public class MathOp {
    private int x;
    private int y;
    private int z;

    public MathOp() {}

    public MathOp(int x, int y, int z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }
    //added methods
    public int calculateSum() {
        return x + 2 * y + 3 * z;
    }

    public int calculatePrd() {
        return x * 2 * y * 3 * z;
    }

    // Getters and setters
    public int getX() { return x; }
    public int getY() { return y; }
    public int getZ() { return z; }

    public void setX(int x) { this.x = x; }
    public void setY(int y) { this.y = y; }
    public void setZ(int z) { this.z = z; }
}
