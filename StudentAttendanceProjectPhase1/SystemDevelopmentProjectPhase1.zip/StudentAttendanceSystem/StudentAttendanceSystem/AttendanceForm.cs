﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace StudentAttendanceSystem
{
    public partial class AttendanceForm : Form
    {
        private List<Student> students;
        private List<AttendanceRecord> attendanceRecords = new List<AttendanceRecord>();

        private ListBox lstStudents;
        private ComboBox cmbStatus;
        private Button btnSaveAttendance;

        public AttendanceForm(List<Student> registeredStudents)
        {
            students = registeredStudents;
            InitializeComponent();
        }

        private void AttendanceForm_Load(object sender, EventArgs e)
        {
            // Populate students in the ListBox
            foreach (var student in students)
            {
                lstStudents.Items.Add($"{student.Name} ({student.ID})");
            }

            // Set up attendance status options
            cmbStatus.Items.AddRange(new string[] { "Present", "Absent", "Late" });
            cmbStatus.SelectedIndex = 0;
        }

        private void btnSaveAttendance_Click(object sender, EventArgs e)
        {
            if (lstStudents.SelectedIndex == -1)
            {
                MessageBox.Show("Please select a student.", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string selectedStudentInfo = lstStudents.SelectedItem.ToString();

            // Extract student ID from format "Name (ID)"
            int startIndex = selectedStudentInfo.IndexOf('(');
            int endIndex = selectedStudentInfo.IndexOf(')');
            string studentID = selectedStudentInfo.Substring(startIndex + 1, endIndex - startIndex - 1);

            string status = cmbStatus.SelectedItem.ToString();

            AttendanceRecord record = new AttendanceRecord
            {
                StudentID = studentID,
                Status = status
            };

            attendanceRecords.Add(record);

            MessageBox.Show($"Attendance marked as {status} for student {studentID}.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void InitializeComponent()
        {
            this.lstStudents = new System.Windows.Forms.ListBox();
            this.cmbStatus = new System.Windows.Forms.ComboBox();
            this.btnSaveAttendance = new System.Windows.Forms.Button();

            this.SuspendLayout();

            // 
            // lstStudents
            // 
            this.lstStudents.FormattingEnabled = true;
            this.lstStudents.Location = new System.Drawing.Point(30, 50);
            this.lstStudents.Name = "lstStudents";
            this.lstStudents.Size = new System.Drawing.Size(200, 95);
            this.lstStudents.TabIndex = 0;

            // 
            // cmbStatus
            // 
            this.cmbStatus.FormattingEnabled = true;
            this.cmbStatus.Location = new System.Drawing.Point(30, 20);
            this.cmbStatus.Name = "cmbStatus";
            this.cmbStatus.Size = new System.Drawing.Size(121, 21);
            this.cmbStatus.TabIndex = 1;

            // 
            // btnSaveAttendance
            // 
            this.btnSaveAttendance.Location = new System.Drawing.Point(70, 160);
            this.btnSaveAttendance.Name = "btnSaveAttendance";
            this.btnSaveAttendance.Size = new System.Drawing.Size(120, 30);
            this.btnSaveAttendance.TabIndex = 2;
            this.btnSaveAttendance.Text = "Save Attendance";
            this.btnSaveAttendance.UseVisualStyleBackColor = true;
            this.btnSaveAttendance.Click += new System.EventHandler(this.btnSaveAttendance_Click);

            // 
            // AttendanceForm
            // 
            this.ClientSize = new System.Drawing.Size(280, 220);
            this.Controls.Add(this.btnSaveAttendance);
            this.Controls.Add(this.cmbStatus);
            this.Controls.Add(this.lstStudents);
            this.Name = "AttendanceForm";
            this.Text = "Attendance Form";
            this.Load += new System.EventHandler(this.AttendanceForm_Load);
            this.ResumeLayout(false);
        }
    }

    
    }

