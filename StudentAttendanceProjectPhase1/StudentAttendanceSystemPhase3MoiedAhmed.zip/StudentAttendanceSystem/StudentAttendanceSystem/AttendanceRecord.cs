﻿using System;

public class AttendanceRecord
{
    public string StudentID { get; set; }
    
    public string Date { get; set; }
    public string Status { get; set; }
}
