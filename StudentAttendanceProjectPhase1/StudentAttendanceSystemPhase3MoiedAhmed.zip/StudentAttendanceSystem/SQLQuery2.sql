﻿INSERT INTO Users (Username, PasswordHash, Role)
VALUES ('admin', 'admin123hashed', 'Admin');



