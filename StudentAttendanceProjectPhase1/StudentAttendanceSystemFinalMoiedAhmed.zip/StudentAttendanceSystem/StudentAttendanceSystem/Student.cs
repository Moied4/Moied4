﻿namespace StudentAttendanceSystem
{
    public class Student
    {
        public string Name { get; set; }
        public string StudentID { get; set; }
        public string Class { get; set; }
        public string Section { get; set; }
        public string Contact { get; set; }
    }
}
